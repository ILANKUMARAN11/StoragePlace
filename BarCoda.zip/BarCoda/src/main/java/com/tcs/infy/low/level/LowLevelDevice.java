package com.tcs.infy.low.level;

import org.usb4java.Device;
import org.usb4java.DeviceDescriptor;
import org.usb4java.DeviceHandle;
import org.usb4java.DeviceList;
import org.usb4java.LibUsb;
import org.usb4java.LibUsbException;

public class LowLevelDevice {
	
	
	/** The vendor ID of the Samsung Galaxy Nexus. */
   // private static final short VENDOR_ID = 0x04e8;

    /** The vendor ID of the Samsung Galaxy Nexus. */
    //private static final short PRODUCT_ID = 0x6860;

    /** The ADB interface number of the Samsung Galaxy Nexus. */
    //private static final byte INTERFACE = 1;

    /** The ADB input endpoint of the Samsung Galaxy Nexus. */
    //private static final byte IN_ENDPOINT = (byte) 0x83;

    /** The ADB output endpoint of the Samsung Galaxy Nexus. */
   // private static final byte OUT_ENDPOINT = 0x03;

    /** The communication timeout in milliseconds. */
   // private static final int TIMEOUT = 5000;
	
    private short VENDOR_ID;

    private short PRODUCT_ID;

    private byte INTERFACE;

    private byte IN_ENDPOINT;

    private byte OUT_ENDPOINT;

    private int TIMEOUT;
	
	public LowLevelDevice(short VENDOR_ID,short PRODUCT_ID,byte INTERFACE,byte IN_ENDPOINT,byte OUT_ENDPOINT,int TIMEOUT)
	{
		this.VENDOR_ID=VENDOR_ID;
		this.PRODUCT_ID=PRODUCT_ID;
		this.INTERFACE=INTERFACE;
		this.IN_ENDPOINT=IN_ENDPOINT;
		this.OUT_ENDPOINT=OUT_ENDPOINT;
		this.TIMEOUT=TIMEOUT;
	}
	
	public LowLevelDevice()
	{
		
	}
	
	
	public Device findDevice(short vendorId, short productId)
	{
	    // Read the USB device list
	    DeviceList list = new DeviceList();
	    int result = LibUsb.getDeviceList(null, list);
	    if (result < 0) throw new LibUsbException("Unable to get device list", result);

	    try
	    {
	        // Iterate over all devices and scan for the right one
	        for (Device device: list)
	        {
	            DeviceDescriptor descriptor = new DeviceDescriptor();
	            result = LibUsb.getDeviceDescriptor(device, descriptor);
	            if (result != LibUsb.SUCCESS) throw new LibUsbException("Unable to read device descriptor", result);
	            
	            System.out.println("VENDOR ID"+descriptor.idVendor());
	            
	            System.out.println("VENDOR ID"+descriptor.idProduct());
	            if (descriptor.idVendor() == vendorId && descriptor.idProduct() == productId) return device;
	        }
	    }
	    finally
	    {
	        // Ensure the allocated device list is freed
	        LibUsb.freeDeviceList(list, true);
	    }

	    // Device not found
	    return null;
	}
	
	
	public void deviceHandles(Device device)
	{
		DeviceHandle handle = new DeviceHandle();
		int result = LibUsb.open(device, handle);
		if (result != LibUsb.SUCCESS) throw new LibUsbException("Unable to open USB device", result);
		try
		{
			
			this.getInterfaces(handle,INTERFACE);
		    // Use device handle here
		}
		finally
		{
		    LibUsb.close(handle);
		}

	}
	
	
	public void getInterfaces(DeviceHandle handle,int interfaceNumber)
	{
		
		
		int result = LibUsb.claimInterface(handle, interfaceNumber);
		if (result != LibUsb.SUCCESS) throw new LibUsbException("Unable to claim interface", result);
		try
		{
		    // Use interface here
		}
		finally
		{
		    result = LibUsb.releaseInterface(handle, interfaceNumber);
		    if (result != LibUsb.SUCCESS) throw new LibUsbException("Unable to release interface", result);
		}

	}
	
	public void getInterfaceButDetach(DeviceHandle handle,int interfaceNumber)
	{
		// Check if kernel driver must be detached
		boolean detach = LibUsb.hasCapability(LibUsb.CAP_SUPPORTS_DETACH_KERNEL_DRIVER) && 
				LibUsb.kernelDriverActive(handle, interfaceNumber)==1;

		// Detach the kernel driver
		if (detach)
		{
		    int result = LibUsb.detachKernelDriver(handle,  interfaceNumber);
		    if (result != LibUsb.SUCCESS) throw new LibUsbException("Unable to detach kernel driver", result);
		}

		// Communicate with the device
		

		// Attach the kernel driver again if needed
		if (detach)
		{
		    int result = LibUsb.attachKernelDriver(handle,  interfaceNumber);
		    if (result != LibUsb.SUCCESS) throw new LibUsbException("Unable to re-attach kernel driver", result);
		}

	}
	
	
	public Device findDevice()//(short vendorId, short productId)
	{
	    // Read the USB device list
	    DeviceList list = new DeviceList();
	    int result = LibUsb.getDeviceList(null, list);
	    if (result < 0) throw new LibUsbException("Unable to get device list", result);

	    try
	    {
	        // Iterate over all devices and scan for the right one
	        for (Device device: list)
	        {
	            DeviceDescriptor descriptor = new DeviceDescriptor();
	            result = LibUsb.getDeviceDescriptor(device, descriptor);
	            if (result != LibUsb.SUCCESS) throw new LibUsbException("Unable to read device descriptor", result);
	            
	            System.out.println("VENDOR ID"+descriptor.idVendor());
	            
	            System.out.println("VENDOR ID"+descriptor.idProduct());
	            //if (descriptor.idVendor() == vendorId && descriptor.idProduct() == productId) return device;
	        }
	    }
	    finally
	    {
	        // Ensure the allocated device list is freed
	        LibUsb.freeDeviceList(list, true);
	    }

	    // Device not found
	    return null;
	}
	
	
	public int init()
	{
		int result = LibUsb.init(null);
		
		if (result != LibUsb.SUCCESS){
			result=LibUsb.SUCCESS;
		     throw new LibUsbException("Unable to initialze libusb",result);
		}
		
		return result;
	}

}
