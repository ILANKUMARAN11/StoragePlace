package com.tcs.infy.high.level;

import java.util.List;

import javax.usb.UsbClaimException;
import javax.usb.UsbConfiguration;
import javax.usb.UsbConst;
import javax.usb.UsbControlIrp;
import javax.usb.UsbDevice;
import javax.usb.UsbDeviceDescriptor;
import javax.usb.UsbDisconnectedException;
import javax.usb.UsbEndpoint;
import javax.usb.UsbException;
import javax.usb.UsbHostManager;
import javax.usb.UsbHub;
import javax.usb.UsbInterface;
import javax.usb.UsbInterfacePolicy;
import javax.usb.UsbNotActiveException;
import javax.usb.UsbPipe;
import javax.usb.UsbServices;
import javax.usb.event.UsbPipeDataEvent;
import javax.usb.event.UsbPipeErrorEvent;
import javax.usb.event.UsbPipeListener;

public class HighLevelDevice {
	
	
	public UsbDevice getUsbRootHoob() {

		try {
			final UsbServices services = UsbHostManager.getUsbServices();
			return services.getRootUsbHub();
		} catch (SecurityException e) {
			e.printStackTrace();
		} catch (UsbException e) {
			e.printStackTrace();
		}

		return null;
	}
	
	public UsbDevice findDeviceByVenorId(UsbHub hub, short vendorId, short productId)
	{
	    for (UsbDevice device : (List<UsbDevice>) hub.getAttachedUsbDevices())
	    {
	        UsbDeviceDescriptor desc = device.getUsbDeviceDescriptor();
	        System.out.println("VenDo_ID : "+desc.idVendor()+",  Prodcut_Id : "+desc.idProduct()
	        
	        		
	        		
	        +"    "+desc.bDeviceProtocol()
	        		
	        		
	        		);
	        if (desc.idVendor() == vendorId && desc.idProduct() == productId) 
	        {
	        	System.out.println("DEVICE FOUND");
	        	return device;
	        }
	        if (device.isUsbHub())
	        {
	            device = findDeviceByVenorId((UsbHub) device, vendorId, productId);
	            if (device != null) 
	            	{
	            	  System.out.println("DEVICE FOUND");
	            	return device;
	            	} else { throw new NullPointerException("DEVICE NOT FOUND");}
	        }
	    }
	    return null;
	}
	
	
	public UsbDevice findDevice(UsbHub hub)
	{
	    for (UsbDevice device : (List<UsbDevice>) hub.getAttachedUsbDevices())
	    {
	        UsbDeviceDescriptor desc = device.getUsbDeviceDescriptor();
	        
	        //controlRequest
	        
	        System.out.println("VenDo_ID : "+desc.idVendor()+",  Prodcut_Id : "+desc.idProduct());
	    }
	    return null;
	}

	public void controlRequest(UsbDevice device) throws Exception
	{
		UsbControlIrp irp = device.createUsbControlIrp(
			    (byte) (UsbConst.REQUESTTYPE_DIRECTION_IN
			          | UsbConst.REQUESTTYPE_TYPE_STANDARD
			          | UsbConst.REQUESTTYPE_RECIPIENT_DEVICE),
			    UsbConst.REQUEST_GET_CONFIGURATION,
			    (short) 0,
			    (short) 0
			    );
			irp.setData(new byte[1]);
			device.syncSubmit(irp);
			System.out.println(irp.getData()[0]);

	}
	
	
	public UsbInterface getDeviceInterface(UsbDevice device, int index) {

		UsbConfiguration configuration = device.getActiveUsbConfiguration();
		UsbInterface iface = (UsbInterface) configuration.getUsbInterfaces().get(index); // there can be more 1,2,3..

		return iface;
	}
	
	
	public void getClaim(UsbInterface iface) throws Exception {
		
		iface.claim();

	}
	
	public void getForceClaim(UsbInterface iface) throws Exception {
		
		iface.claim(new UsbInterfacePolicy()
		{            
		    public boolean forceClaim(UsbInterface usbInterface)
		    {
		        return true;
		    }
		});


	}
	
	public void readMessage(UsbInterface iface, 
			int endPoint){
		
		UsbPipe pipe = null;

		try {
			this.getClaim(iface);
			//this.getForceClaim(iface);

			UsbEndpoint endpoint = (UsbEndpoint) iface.getUsbEndpoints().get(endPoint); // there can be more 1,2,3..
			pipe = endpoint.getUsbPipe();
			pipe.open();
			
		    byte[] data = new byte[8];
		    int received = pipe.syncSubmit(data);
		    System.out.println(received + " bytes received");

			pipe.close();

		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			try {
				iface.release();
			} catch (UsbClaimException e) {
				e.printStackTrace();
			} catch (UsbNotActiveException e) {
				e.printStackTrace();
			} catch (UsbDisconnectedException e) {
				e.printStackTrace();
			} catch (UsbException e) {
				e.printStackTrace();
			}
		}
		
	}

	public void readMessageAsynch(UsbInterface iface, 
			int endPoint){

		UsbPipe pipe = null;

		try {
			this.getForceClaim(iface);

			UsbEndpoint endpoint = (UsbEndpoint) iface.getUsbEndpoints().get(endPoint); // there can be more 1,2,3..
			pipe = endpoint.getUsbPipe();

			pipe.open();

			pipe.addUsbPipeListener(new UsbPipeListener()
			{            
				public void errorEventOccurred(UsbPipeErrorEvent event)
				{
					UsbException error = event.getUsbException();
					error.printStackTrace();
				}

				public void dataEventOccurred(UsbPipeDataEvent event)
				{
					byte[] data = event.getData();

					System.out.println(data + " bytes received");
				}
			});
			
//			pipe.close();

		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			try {
				iface.release();
			} catch (UsbClaimException e) {
				e.printStackTrace();
			} catch (UsbNotActiveException e) {
				e.printStackTrace();
			} catch (UsbDisconnectedException e) {
				e.printStackTrace();
			} catch (UsbException e) {
				e.printStackTrace();
			}
		}

	}
	

}
