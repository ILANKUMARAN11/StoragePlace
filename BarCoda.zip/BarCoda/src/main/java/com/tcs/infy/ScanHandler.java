package com.tcs.infy;

import javax.usb.UsbDevice;
import javax.usb.UsbHub;
import javax.usb.UsbInterface;

import com.tcs.infy.high.level.HighLevelDevice;

public class ScanHandler {

	public static void main(String[] args) {
		
		try {
		

			
			HighLevelDevice usb4java = new HighLevelDevice();
			UsbDevice usbDevice = usb4java.findDeviceByVenorId((UsbHub)usb4java.getUsbRootHoob(),(short) (2652), (short) (17664));
			
			UsbInterface iface=usb4java.getDeviceInterface(usbDevice,0);
			
			usb4java.readMessage(iface, (byte) 0x83);
		
		
		
		} catch(Exception e)
		{
			e.printStackTrace();
		}
		

	}
	
}
