package com.tcs.infy.mapper;

import java.math.BigDecimal;

public class UserDetailsVo {
	
	
	
	
	
	
	public UserDetailsVo() 
	{
		this.companyId=new BigDecimal(1189);
		this.firstName="ILAN";
		this.lastName="KUMARAN";
		this.emailAddress="ilankumaran.i@gmail.com";
		this.phoneNumber="7539913146";
		this.mobileNumber="9442379263";
		this.role="Consultant";
		this.password="";
		this.maritalStatus="Married";
	}
	
	
	
	private BigDecimal companyId;
	private String firstName;
	private String lastName;
	private String emailAddress;
	private String phoneNumber;
	private String mobileNumber;
	private String role;
	private String password;
	private String maritalStatus;
	public BigDecimal getCompanyId() {
		return companyId;
	}
	public void setCompanyId(BigDecimal companyId) {
		this.companyId = companyId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getMaritalStatus() {
		return maritalStatus;
	}
	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}
	
	
	
	
	
	

	
}
