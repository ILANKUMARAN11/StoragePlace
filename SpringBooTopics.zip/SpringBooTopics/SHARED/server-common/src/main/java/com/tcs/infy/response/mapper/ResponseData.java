package com.tcs.infy.response.mapper;

import org.springframework.boot.jackson.JsonComponent;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonProperty;

@Component
@JsonComponent
public class ResponseData
{
	
	
	public ResponseData()
	{
		
	}
	
	public ResponseData(Object data,boolean success,String message)
	{
		this.data=data;
		this.success=success;
		this.message=message;
	}
	
	@JsonProperty("DATA")
	private Object data;
	
	@JsonProperty("SUCCESS")
	private boolean success;
	
	@JsonProperty("MESSAGE")
	private String message;

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	
	

}
