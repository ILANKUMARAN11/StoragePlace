package com.tcs.infy.mapper;

import org.springframework.boot.jackson.JsonComponent;

@JsonComponent
public class VehicleVo {

	
	

	
	public VehicleVo() {

		this.vehicleNumber = "TN 31 BV 7194";
		this.vehicleType = "SUV";
		this.engineeNumber = "118906119209112018";
		this.driverName = "Ganesh";

	}




	public VehicleVo(String vehicleNumber,String vehicleType,String engineeNumber,String driverName) {

		this.vehicleNumber = vehicleNumber;
		this.vehicleType = vehicleType;
		this.engineeNumber = engineeNumber;
		this.driverName = driverName;

	}
	

	private String vehicleNumber;
	private String vehicleType;
	private String engineeNumber;
	private String driverName;



	public String getVehicleNumber() {
		return vehicleNumber;
	}

	public void setVehicleNumber(String vehicleNumber) {
		this.vehicleNumber = vehicleNumber;
	}

	public String getVehicleType() {
		return vehicleType;
	}

	public void setVehicleType(String vehicleType) {
		this.vehicleType = vehicleType;
	}

	public String getEngineeNumber() {
		return engineeNumber;
	}

	public void setEngineeNumber(String engineeNumber) {
		this.engineeNumber = engineeNumber;
	}

	public String getDriverName() {
		return driverName;
	}

	public void setDriverName(String driverName) {
		this.driverName = driverName;
	}

}
