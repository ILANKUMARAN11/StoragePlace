package com.tcs.infy.constants;

public class CommonValue 
{
	
	public static final boolean SUCCESS = true;
	public static final boolean FAILURE = false;

}
