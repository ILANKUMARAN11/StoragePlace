package com.tcs.infy.serviceImpl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.tcs.infy.mapper.VehicleVo;
import com.tcs.infy.service.VehicleService;



@Service
public class VehicleServiceImpl implements VehicleService
{
	Logger logger = LoggerFactory.getLogger(VehicleServiceImpl.class);

	
	
	
	
	
	@Override
	public VehicleVo getVehicle()
	{
		return new VehicleVo();
	}
	
	
	
	

}
