package com.tcs.infy.controller;


import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.tcs.infy.constants.CommonValue;
import com.tcs.infy.mapper.VehicleVo;
import com.tcs.infy.response.mapper.ResponseData;
import com.tcs.infy.service.VehicleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

@RestController
@EnableSwagger2
public class FeignClientTopicController {



    @GetMapping(value = "/vehicle/getVehicle/{vhNo}",produces = MediaType.APPLICATION_JSON_VALUE)
    public VehicleVo findVehicle(@PathVariable(value="vhNo") String vehicleNumber)
    {
        List<VehicleVo> vehicleList= Arrays.asList( new VehicleVo[]{
                new VehicleVo("11","aa","aa","aa"),
                new VehicleVo("12","bb","bb","cc"),
                new VehicleVo("13","cc","cc","cc"),
                new VehicleVo("14","dd","dd","dd"),
                new VehicleVo("15","ee","ee","ee")});
        return vehicleList.stream().filter(i->i.getVehicleNumber().equalsIgnoreCase(vehicleNumber)).findFirst().orElse(new VehicleVo());
    }





    @GetMapping(value = "/vehicle/getAllVehicle.brio",produces = MediaType.APPLICATION_JSON_VALUE)
    public List<VehicleVo> getAllVehicle()
    {
        List<VehicleVo> vehicleList= Arrays.asList( new VehicleVo[]{
                new VehicleVo("1","aa","aa","aa"),
                new VehicleVo("2","bb","bb","cc"),
                new VehicleVo("3","cc","cc","cc"),
                new VehicleVo("4","dd","dd","dd"),
                new VehicleVo("5","ee","ee","ee")});
        return  vehicleList;
    }
}
