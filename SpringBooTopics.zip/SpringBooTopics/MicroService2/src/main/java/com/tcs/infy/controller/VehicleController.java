package com.tcs.infy.controller;

import com.tcs.infy.controller.hystrix.VehicleHystrix;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.tcs.infy.constants.CommonValue;
import com.tcs.infy.mapper.VehicleVo;
import com.tcs.infy.response.mapper.ResponseData;
import com.tcs.infy.service.VehicleService;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

@RestController
@EnableSwagger2
public class VehicleController  extends VehicleHystrix {
	
	@Autowired
	VehicleService vehicleService;
	
	@Autowired
	ResponseData responseData;
	
	
	 	@GetMapping(value = "/current/vehicle/status.brio",produces = MediaType.APPLICATION_JSON_VALUE)
	    public ResponseData getVehicleStatus() 
	    {
	 		VehicleVo vehicleVo=vehicleService.getVehicle();
	    	responseData.setData(vehicleVo);
    		responseData.setMessage("Vehicle point and Vehicle selected successfully for this vehicleNumber==>"+(String)vehicleVo.getVehicleNumber());
    		responseData.setSuccess(CommonValue.SUCCESS);
    		
    		return responseData;
	    }
	    
	    
	 	@HystrixCommand(fallbackMethod="iAmHystrixMethod")
	 	@GetMapping(value = "/test/hystrix.brio",produces = MediaType.APPLICATION_JSON_VALUE)
	    public VehicleVo testHystrix() 
	    {
	 		System.out.println("==========>>> First time called and Exception occured <<<==========");
	 		
	 		if(true)
	 		throw new RuntimeException();
    		return new VehicleVo();
	    }


	 	
	 	
	   
}
