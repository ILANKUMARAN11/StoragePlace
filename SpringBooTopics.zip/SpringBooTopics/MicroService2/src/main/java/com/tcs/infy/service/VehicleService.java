package com.tcs.infy.service;

import com.tcs.infy.mapper.VehicleVo;

public interface VehicleService {

	public VehicleVo getVehicle();

}
