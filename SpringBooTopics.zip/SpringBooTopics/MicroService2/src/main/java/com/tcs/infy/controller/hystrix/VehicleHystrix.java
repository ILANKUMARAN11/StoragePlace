package com.tcs.infy.controller.hystrix;

import com.tcs.infy.mapper.VehicleVo;

public class VehicleHystrix {

    public VehicleVo iAmHystrixMethod()
    {
        System.out.println("==========>>> Inside the fallBack method <<<==========");
        VehicleVo vehicleVo=new VehicleVo();
        vehicleVo.setVehicleNumber("dummy");
        vehicleVo.setVehicleType("dummy");
        vehicleVo.setEngineeNumber("dummy");
        vehicleVo.setDriverName("dummy");
        return vehicleVo;
    }
}
