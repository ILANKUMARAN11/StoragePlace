package com.tcs.infy.entity;

import javax.persistence.*;

@Entity
@Table(name = "Branch")
public class Branch {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id")
    private int pk_Branch_Id;

    @Column(name = "branch_Id")
    private int branch_Id;

    @Column(name = "branchLocation")
    private String branchLocation;

    @ManyToOne(cascade=CascadeType.ALL)
    @JoinColumn(name="Region_ID")
    private Region region;

    public int getPk_Branch_Id() {
        return pk_Branch_Id;
    }

    public void setPk_Branch_Id(int pk_Branch_Id) {
        this.pk_Branch_Id = pk_Branch_Id;
    }

    public int getBranch_Id() {
        return branch_Id;
    }

    public void setBranch_Id(int branch_Id) {
        this.branch_Id = branch_Id;
    }

    public String getBranchLocation() {
        return branchLocation;
    }

    public void setBranchLocation(String branchLocation) {
        this.branchLocation = branchLocation;
    }

    public Region getRegion() {
        return region;
    }

    public void setRegion(Region region) {
        this.region = region;
    }
}
