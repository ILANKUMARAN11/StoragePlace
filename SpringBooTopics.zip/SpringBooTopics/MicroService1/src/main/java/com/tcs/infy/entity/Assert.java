package com.tcs.infy.entity;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "Assert")
public class Assert {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id")
    private int pk_Assert_id;

    @Column(name = "assertName")
    private String assertName;

    @Column(name = "assertType")
    private String assertType;

    @Column(name = "serialNo")
    private String serialNo;

    @Column(name = "purchasedDate")
    private Date purchasedDate;

    @Column(name = "modelNo")
    private String modelNo;

    public int getPk_Assert_id() {
        return pk_Assert_id;
    }

    public void setPk_Assert_id(int pk_Assert_id) {
        this.pk_Assert_id = pk_Assert_id;
    }

    public String getAssertName() {
        return assertName;
    }

    public void setAssertName(String assertName) {
        this.assertName = assertName;
    }

    public String getAssertType() {
        return assertType;
    }

    public void setAssertType(String assertType) {
        this.assertType = assertType;
    }

    public String getSerialNo() {
        return serialNo;
    }

    public void setSerialNo(String serialNo) {
        this.serialNo = serialNo;
    }

    public Date getPurchasedDate() {
        return purchasedDate;
    }

    public void setPurchasedDate(Date purchasedDate) {
        this.purchasedDate = purchasedDate;
    }

    public String getModelNo() {
        return modelNo;
    }

    public void setModelNo(String modelNo) {
        this.modelNo = modelNo;
    }
}
