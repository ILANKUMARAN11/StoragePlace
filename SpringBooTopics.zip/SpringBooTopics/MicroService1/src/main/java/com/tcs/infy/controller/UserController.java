package com.tcs.infy.controller;

import com.tcs.infy.entity.User;
import com.tcs.infy.service.UserServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;


import springfox.documentation.swagger2.annotations.EnableSwagger2;

@RestController
@EnableSwagger2
@CrossOrigin
@RequestMapping
public class UserController {


	@Autowired
	UserServiceImpl userService;


	@PostMapping(value = "/admin/add/user/byAdmin.brio", produces = MediaType.APPLICATION_JSON_VALUE)
	public User addUser(@RequestBody User user) {

		return userService.saveUser(user);

	}
	


}
