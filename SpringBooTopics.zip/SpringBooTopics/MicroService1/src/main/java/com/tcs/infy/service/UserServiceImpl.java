package com.tcs.infy.service;

import com.tcs.infy.entity.User;
import com.tcs.infy.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl {

    @Autowired
    UserRepository usersRepository;

    public User saveUser(User user)
    {
        return usersRepository.save(user);
    }


    public User updateUser(User user)
    {
        User foundUser=usersRepository.findById(user.getId());
        foundUser.setActive(user.getActive());
        return usersRepository.save(foundUser);
    }

    public void deleteUser(User user)
    {
         usersRepository.delete(user);
    }
}
