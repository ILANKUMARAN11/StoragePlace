package com.tcs.infy.entity;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Collection;

@Entity
@Table(name = "Region")
public class Region {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id")
    private int pk_Region_id;

    @Column(name = "regionId")
    private int regionId;

    @Column(name = "regionName")
    private String regionName;

    @OneToMany(mappedBy="region",cascade=CascadeType.ALL)
    private Collection<Branch> branch=new ArrayList<Branch>();

    public int getPk_Region_id() {
        return pk_Region_id;
    }

    public void setPk_Region_id(int pk_Region_id) {
        this.pk_Region_id = pk_Region_id;
    }

    public int getRegionId() {
        return regionId;
    }

    public void setRegionId(int regionId) {
        this.regionId = regionId;
    }

    public String getRegionName() {
        return regionName;
    }

    public void setRegionName(String regionName) {
        this.regionName = regionName;
    }

    public Collection<Branch> getBranch() {
        return branch;
    }

    public void setBranch(Collection<Branch> branch) {
        this.branch = branch;
    }
}
