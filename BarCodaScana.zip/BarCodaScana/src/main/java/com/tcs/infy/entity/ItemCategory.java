package com.tcs.infy.entity;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity(name = "ItemCategory")
public class ItemCategory {

	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;
	
	@Column(name="Category")
    private int category;
	
	
	@Column(name="Delstatus")
    private String delStatus;
	
	@Column(name="Modifiedby")
    private String modifiedBy;
    
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="ModifiedAt")
    private Date modifiedAt;
	
    
    public ItemCategory() {
  
    }


	public long getId() {
		return id;
	}


	public void setId(long id) {
		this.id = id;
	}


	public int getCategory() {
		return category;
	}


	public void setCategory(int category) {
		this.category = category;
	}


	public String getDelStatus() {
		return delStatus;
	}


	public void setDelStatus(String delStatus) {
		this.delStatus = delStatus;
	}


	public String getModifiedBy() {
		return modifiedBy;
	}


	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}


	public Date getModifiedAt() {
		return modifiedAt;
	}


	public void setModifiedAt(Date modifiedAt) {
		this.modifiedAt = modifiedAt;
	}
	
	
	@OneToOne(mappedBy="itemCategory",cascade=CascadeType.ALL)
    private ItemMaster itemMaster;


	public ItemMaster getItemMaster() {
		return itemMaster;
	}


	public void setItemMaster(ItemMaster itemMaster) {
		this.itemMaster = itemMaster;
	}
	
	

	
}
