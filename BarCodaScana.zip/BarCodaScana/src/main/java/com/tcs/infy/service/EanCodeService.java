package com.tcs.infy.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tcs.infy.entity.ItemEANcode;
import com.tcs.infy.repo.ItemEanCodeRepo;

@Service
public class EanCodeService {
	
	@Autowired
	ItemEanCodeRepo itemEanCodeRepo;
	
	
	@Transactional
	public ItemEANcode getEanCode(long id)
	{
		return itemEanCodeRepo.findById(id).orElse(null);
	}

}
